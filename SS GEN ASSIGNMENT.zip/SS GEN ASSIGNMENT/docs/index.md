# Hello World
# Welcome to My Personal Interest Site
import './style.css'; // Import your custom styles
import DefaultTheme from 'vitepress/theme';

export default {
    ...DefaultTheme,
};

<div class="hero">
  <h1>Hi, I'm Rohit!</h1>
  <p>Explore my hobbies, projects, and interests below.</p>
</div>

## About This Site
This site showcases my personal projects and passions. Navigate using the links above!
