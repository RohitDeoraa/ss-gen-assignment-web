---
title: About Me
---

# About Me

Hi, I'm Rohit! I enjoy coding, design, and exploring new technologies.
