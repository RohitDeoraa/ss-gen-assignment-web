import { defineConfig } from 'vitepress';

export default defineConfig({
  title: "Rohit's Personal Site",
  description: "A portfolio and hobby showcase.",
  themeConfig: {
    nav: [
      { text: "Home", link: "/" },
      { text: "About Me", link: "/about" },
      { text: "Projects", link: "/projects" },
      { text: "Hobbies", link: "/hobbies" },
      { text: "Contact", link: "/contact" },
    ]
  }
});

