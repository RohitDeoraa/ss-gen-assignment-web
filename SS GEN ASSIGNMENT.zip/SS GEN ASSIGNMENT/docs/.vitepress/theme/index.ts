import './style.css';  // Link to your custom CSS file
import DefaultTheme from 'vitepress/theme';

export default {
  ...DefaultTheme,
};

